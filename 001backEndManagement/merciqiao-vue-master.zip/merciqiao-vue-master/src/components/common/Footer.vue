<template>
  <footer>
      <div class="footer_content">
          ©2018 merciqiao
      </div>
  </footer>
</template>
<style lang="scss">
    footer{
        border-top:1px solid #ddd;
        flex: 0 0 auto;
        .footer_content{
            width: 300px;
            margin: 0 auto;
            text-align: center;
            line-height: 60px;
            height: 60px;
            color:#606266;
        }
    }
</style>

